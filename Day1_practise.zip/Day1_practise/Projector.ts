class Projector{
	brand:string;
	price:number;
	color:string;
	turnOn(){
	console.log("projector turned on");
	}
	turnOff(){
	console.log("Projector turned off");
	}
	displayPrice(projPrice){
	this.price=projPrice;
	console.log("The price is:" +projPrice);
	
	}
	displayColor(dispColor){
	this.color=dispColor;
	console.log("Color is:" +dispColor);
	
	}
}
var details=new Projector();
details.turnOn();
details.turnOff();
details.brand="epison";
details.color="blue";
details.displayColor(details.color);
details.displayPrice("5000");

