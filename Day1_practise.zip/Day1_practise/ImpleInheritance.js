var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.setName = function (name) {
        this.name = name;
        console.log("The Name of Employee is: " + name);
    };
    Employee.prototype.setDetails = function (name, empId, designation, location) {
        this.name = name;
        this.empId = empId;
        this.designation = designation;
        this.location = location;
        console.log("Employee Details =================");
        console.log("The name of the employee is: " + name);
        console.log("The employee ID is: " + empId);
        console.log("The designation is: " + designation);
        console.log("The location is:" + location);
        console.log("===================================");
    };
    Employee.prototype.getName = function () {
        return this.name;
    };
    return Employee;
}());
var Admin = /** @class */ (function (_super) {
    __extends(Admin, _super);
    function Admin() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Admin.prototype.setAdminDetails = function (adminName, adminLocation) {
        console.log("Admin details");
        console.log("========================");
        console.log("The name of Admin is:" + adminName + "\n" + "the location of Admin is:" + adminLocation);
        this.adminName = adminName;
        this.adminLocation = adminLocation;
    };
    return Admin;
}(Employee));
var Manager = /** @class */ (function () {
    function Manager() {
    }
    Manager.prototype.setManager = function (nameOfManager) {
        this.manName = nameOfManager;
        console.log("====================");
        console.log("The name of manager is: " + nameOfManager);
    };
    return Manager;
}());
var n = new Employee();
n.name = "anila";
n.empId = 100;
n.designation = "consultant";
n.location = "hyderabad";
n.setDetails(n.name, n.empId, n.designation, n.location);
n.setName(n.name);
var a = new Admin();
a.setAdminDetails("priyanka", "Pune");
a.setName("bhavani");
var m = new Manager();
m.setManager("Chandu");
