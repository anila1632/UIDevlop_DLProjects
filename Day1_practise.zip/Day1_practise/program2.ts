class Student{
	name;
	address;

setName(name){
this.name=name;
console.log(name);
}
setAddress(address){
	this.address=address;
	console.log(address);
}
}
var n=new Student();
n.setName("Anila");
n.setAddress("London");