var Projector = /** @class */ (function () {
    function Projector() {
    }
    Projector.prototype.turnOn = function () {
        console.log("projector turned on");
    };
    Projector.prototype.turnOff = function () {
        console.log("Projector turned off");
    };
    Projector.prototype.displayPrice = function (projPrice) {
        this.price = projPrice;
        console.log("The price is:" + projPrice);
    };
    Projector.prototype.displayColor = function (dispColor) {
        this.color = dispColor;
        console.log("Color is:" + dispColor);
    };
    return Projector;
}());
var details = new Projector();
details.turnOn();
details.turnOff();
details.brand = "epison";
details.color = "blue";
details.displayColor(details.color);
details.displayPrice("5000");
