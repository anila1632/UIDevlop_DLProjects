class Employee
{
	name;
	empId;
	designation;
	location;
	setName(name)
	{
	this.name=name;
	console.log("The Name of Employee is: "+name);
	
	}
	setDetails(name,empId,designation,location)
	{
		this.name=name;
		this.empId=empId;
		this.designation=designation;
		this.location=location;
		console.log("Employee Details =================");
		console.log("The name of the employee is: "+name);
		console.log("The employee ID is: "+empId);
		console.log("The designation is: "+designation);
		console.log("The location is:" +location);
		console.log("===================================");
	}
	getName()
	{
	return this.name;
	}
}
class Admin extends Employee
{
adminName;
adminLocation;
setAdminDetails(adminName,adminLocation)
{
	console.log("Admin details");
	console.log("========================");
	console.log("The name of Admin is:" +adminName+ "\n"+ "the location of Admin is:" +adminLocation);
	this.adminName=adminName;
	this.adminLocation=adminLocation;
}
	
}
class Manager
{
	manName;
	manLocation;
	setManager(nameOfManager)
	{
	this.manName=nameOfManager;
	console.log("====================");
	console.log("The name of manager is: "+nameOfManager);
	}
}
var n=new Employee();
n.name="anila";
n.empId=100;
n.designation="consultant";
n.location="hyderabad";
n.setDetails(n.name,n.empId,n.designation,n.location);
n.setName(n.name);
var a=new Admin();

a.setAdminDetails("priyanka","Pune");
a.setName("bhavani");
var m=new Manager();
m.setManager("Chandu");

