var Student = /** @class */ (function () {
    function Student() {
    }
    Student.prototype.setName = function (name) {
        this.name = name;
        console.log(name);
    };
    Student.prototype.setAddress = function (address) {
        this.address = address;
        console.log(address);
    };
    return Student;
}());
var n = new Student();
n.setName("Anila");
n.setAddress("London");
