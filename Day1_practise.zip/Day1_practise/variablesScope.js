var GlobalVariables = /** @class */ (function () {
    function GlobalVariables() {
        this.x = 100;
    }
    GlobalVariables.prototype.displayMore = function () {
        console.log(this.x);
    };
    return GlobalVariables;
}());
var d = new GlobalVariables();
d.displayMore();
