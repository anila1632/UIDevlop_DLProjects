class GlobalVariables
{
	x:number=100;
	displayMore()
	{
	console.log(this.x);
	}
	
}

var d=new GlobalVariables();
d.displayMore();
