var textbox=document.getElementById('textbox01');
var btn=document.getElementById('btn01');
var incompleted=document.getElementById('incompleted');
var completed=document.getElementById('completed');

var addtask=function(){
	/*Creating elements when button*/
	//btn.onclick=function(){}....is it not the correct way???
	var check=document.createElement('input');
	var labelele=document.createElement('label');
	var editbox=document.createElement('input');
	var editbtn=document.createElement('button');
	var deletebtn=document.createElement('button');
	var listli=document.createElement('li');
	/*giving type of element*/
	check.type="checkbox";
	labelele.type="label";
	editbox.type="text";
	// editbtn.type="button";-- need not mention their type
	// deletebtn.type="button";
	//listli.type="list"; -- need not mention their type

	editbtn.innerHTML="EDIT";
	deletebtn.innerHTML="DELETE";

	/*first do not display editbox*/
	editbox.style.display="none";

	/*append the created elements to list and append the list to incomplted ul*/
	
	listli.appendChild(check);
	listli.appendChild(labelele);
	listli.appendChild(editbox);
	listli.appendChild(editbtn);
	listli.appendChild(deletebtn);
	incompleted.appendChild(listli);
	
	/*assign value of task to the label*/
	labelele.innerHTML=textbox.value;//label is a local to this function and textbox is a global variable
	check.onchange=movetask;
	editbtn.onclick=edittask;



	//return false;--need not write this stmt as we are not returning any values through
	/*var completed=document.getElementById("completed");*/
}
btn.onclick=addtask;
var movetask=function(){
	console.log(this);
	var list=this.parentNode.parentNode;
	if (list.id=="incompleted") 
	{
		completed.appendChild(this.parentNode);
	}
	else if(list.id=="completed")
	{
		incompleted.appendChild(this.parentNode);
	}

}
var edittask=function()
{
	//click on edit button, the label value should come in editbox and edit button value should change to update
 if (editbtn.style.display=="none") 
 {
 editbtn.style.display="inline-block";
 editbtn.innerHTML=labelele.value;
 
 }
 else if (editbtn.style.display=="inline-block")
  {
  	editbtn.style.display="none";
  	labelele.innerHTML=editbtn.value;
  }



}
var deletetask=function(){

}
