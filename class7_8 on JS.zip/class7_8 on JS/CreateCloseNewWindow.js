function openSubWindow(){
var pagename=document.getElementById("text01");
if (pagename.value=="Google") {
	window.open("http://www.google.com","","height=300,width=400");
}
else
alert("Please enter Google");
}