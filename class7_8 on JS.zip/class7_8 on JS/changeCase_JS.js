function changetoUpper()
{
	var text1=document.getElementById("text01").value;
	var text2=document.getElementById("text02").value;
if (text2.value==null)
{
	document.getElementById("text02").value=text1.toUpperCase();

}
// else if(text1.value==null)
// {
// 	document.getElementById("text01").value=text2.toUpperCase();
	

// }
else
{
	document.getElementById("text01").value=text2.toUpperCase();
	

}

}

// function changetoUpper()
// {
// 	// var text1=document.getElementById("input").value;
// 	// console.log(text1);
// 	// var text2=document.getElementById("output");	
// 	// text2.innerHTML=text1.value;
// 	// console.log(text2);
// 	document.getElementById("output").value=document.getElementById("input").value.toUpperCase();

// }