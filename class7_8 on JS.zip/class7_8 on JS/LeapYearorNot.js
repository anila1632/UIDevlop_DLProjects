var yearinput=document.getElementById("leap");
console.log(yearinput);
function leapyrornot()
{
	if(yearinput.value%4==0)
	{
		alert("The year"+yearinput.value+"is a leap year");

	}
	else
		alert("The year"+yearinput.value+"is not a leap year");

}