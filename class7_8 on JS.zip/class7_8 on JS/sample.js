var btn=document.getElementById('addbtn');
var textbox=document.getElementById('newtask');
var incompleted=document.getElementById('incompleted');
var completed=document.getElementById('completed');
var addtask=function(){

	// creating elements dynamically
	var check=document.createElement('input');
	var label=document.createElement('label');
	var editbox=document.createElement('input');
	var edit=document.createElement('button');
	var delete1=document.createElement('button');
	var listitem=document.createElement('li');
	/*setting types to created eleemnnts*/
	check.type="checkbox";
	editbox.type="text";
	delete1.innerHTML="DELETE";
	edit.innerHTML="EDIT"
	editbox.style.display="none";
	label.innerHTML=textbox.value;
	/*appending*/
	listitem.appendChild(check);
	listitem.appendChild(label);
	listitem.appendChild(editbox);
	listitem.appendChild(edit);
	listitem.appendChild(delete1);
	incompleted.appendChild(listitem);
	check.onchange=moving;
	edit.onclick=edittask;
	delete1.onclick=deletetask;

		return false;
	/*display elements in incomplete frame */
	
}
var moving=function(){
	console.log(this);
	var list=this.parentNode.parentNode;
	console.log(list);
	if(list.id=="incompleted"){
		completed.appendChild(this.parentNode);
	}else if(list.id=="completed"){
		incompleted.appendChild(this.parentNode)
	}
}

btn.onclick=addtask;
var edittask=function()
{
	console.log(this);
	//alert("edit task");
	var editbox2=this.parentNode.querySelector("input[type=text]");
	console.log(editbox2);
	var label2=this.parentNode.querySelector("label");
	if(editbox2.style.display=="none")
	{
	editbox2.value=label2.innerHTML;
	editbox2.style.display="inline-block";
	this.innerHTML="UPDATE";
	label2.style.display="none";
	}
else if (editbox2.style.display=="inline-block") {
	label2.innerHTML=editbox2.value;
	label2.style.display="inline-block";
	this.innerHTML="EDIT";
	editbox2.style.display="none";
	}
	
}
var deletetask=function(){
	// alert("dleet elements");
	console.log(this);
	this.parentNode.remove();

}




// document.getElementById("psample").innerHTML="this is para";

