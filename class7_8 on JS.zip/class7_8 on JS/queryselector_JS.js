var firstname=document.querySelector("input[text='fname']");
//console.log(firstname);
var images=document.querySelector("#image1");
console.log(images);
document.write("This browser version is:" +navigator.appVersion);
// var images=document.querySelector("img");
// console.log(images);
// var images=document.querySelectorAll("img");
// console.log(images);

var bigimg=function()
{
	images.style.height="100px";
	images.style.width="100px";	
	return false;
}
images.onmouseover=bigimg;
console.log(bigimg);
var smallimg=function()
{
	images.style.height="50px";
	images.style.width="50px";
	return false;
}
images.onmouseout=smallimg;
console.log(smallimg);
function whenkeypresseddown(){
	//var body=document.getElementById('body01');
	document.body.style.backgroundColor="lightblue";
}
var addbtn=document.getElementById('btn01').value;
console.log(addbtn);
var clicked=function()
{
	addbtn.innerHTML="Review";
	console.log(addbtn);
	return false;
}
addbtn.onclick=clicked;
var btnP=document.getElementById('buttonP');
var padd=document.getElementById('addedP');
// var newP=function()
// {
// 	padd.innerHTML="This is new Paragraph";
// 	console.log(newP);
// }
// btnP.onclick=padd;
function whenclicked()
{
	document.getElementById(addedP).innerHTML="This is new Paragraph";
}