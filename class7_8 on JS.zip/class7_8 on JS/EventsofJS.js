var span=document.getElementById('disptime');
console.log(span);
var clock=document.getElementById('clockimg');
var click=function()
{
	span.value=Date();
	return false;
}
clock.onclick=click;
// var text=document.getElementById('sampletext').value;
// console.log(text);
// var selected=function()
// {
// 	text.style.color="black";
// 	return false;
// }
// text.onmouseover=selected;
var timebutton=document.getElementById('timebtn');
//timebutton.value='click me!';
console.log(timebutton);
function timebuttonfordate()
{
	timebutton.innerHTML=Date();


}
console.log(Object);