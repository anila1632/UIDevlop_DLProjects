<html>
<head>
	<title></title>
</head>
<body>
welcome <?php echo $_GET["firstname"];? >
</body>
</html>