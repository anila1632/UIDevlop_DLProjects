var a,b,c;
a=2,b=3;
c=a+b;
var x={firstname:"anila",lastname="priyanka"};
